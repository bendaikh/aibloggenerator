<script setup>
import SuperAdminLayout from '@/Layouts/SuperAdminLayout.vue';
import { Head } from '@inertiajs/vue3';

defineProps({
    assets: {
        type: Array,
        default: () => []
    }
});
</script>

<template>
    <Head title="Assets" />

    <SuperAdminLayout>
        <div class="p-8">
            <div class="flex items-center justify-between mb-8">
                <div>
                    <h1 class="text-3xl font-bold text-white">Assets</h1>
                    <p class="text-gray-400 mt-1">Manage your media files and images</p>
                </div>
                <button class="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                    </svg>
                    Upload Files
                </button>
            </div>

            <!-- Upload Area -->
            <div class="bg-[#1a1a1a] rounded-2xl border-2 border-dashed border-[#3a3a3a] p-12 text-center mb-8 hover:border-emerald-500/50 transition-colors cursor-pointer">
                <svg class="w-16 h-16 text-gray-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                <p class="text-gray-400 text-lg">Drag and drop files here</p>
                <p class="text-gray-500 text-sm mt-2">or click to browse</p>
                <p class="text-gray-600 text-xs mt-4">Supports: JPG, PNG, GIF, SVG, PDF (Max 10MB)</p>
            </div>

            <!-- Assets Grid -->
            <div v-if="assets.length === 0" class="bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] p-12 text-center">
                <svg class="w-16 h-16 text-gray-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p class="text-gray-400 text-lg">No assets yet</p>
                <p class="text-gray-500 text-sm mt-2">Upload your first file to get started</p>
            </div>
        </div>
    </SuperAdminLayout>
</template>

